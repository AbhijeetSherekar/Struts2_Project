CREATE TABLE `invoices` (
  'invoiceId'  INT NOT NULL ,
  'invoiceDate' VARCHAR(255)  NOT NULL,
  'customerName' VARCHAR(255)  NOT NULL,
  'item' VARCHAR(255)  NOT NULL,
  'price' VARCHAR(255) NOT NULL ,
  'quantity' VARCHAR(255) NOT NULL ,
  'totalPrice' VARCHAR(255) NOT NULL,
  'total_invoice_amount' VARCHAR(255) NOT NULL 
);
