CREATE TABLE `customer_details` (
  `customerId` VARCHAR(25) DEFAULT NULL,
  `customerName` VARCHAR(50) NOT NULL,
  `address` VARCHAR(25) DEFAULT NULL,
  `contactNo` VARCHAR(25) DEFAULT NULL
  
);
