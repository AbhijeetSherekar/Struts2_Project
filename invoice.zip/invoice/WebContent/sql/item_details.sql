CREATE TABLE 'item_details' (
  'itemCode ' VARCHAR(50) DEFAULT NULL,
  'itemName' VARCHAR(50) NOT NULL,
  'uom' VARCHAR(105) DEFAULT NULL,
  'price' VARCHAR(25) DEFAULT NULL,
  'quantity' VARCHAR(255) DEFAULT NULL,
  PRIMARY KEY ('itemCode')
);

