package org.websparrow.bean;

public class ItemBean {
	private String iteamCode,itemName,umo,price,quantity;
	

	public String getIteamCode() {
		return iteamCode;
	}

	public void setIteamCode(String iteamCode) {
		this.iteamCode = iteamCode;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public String getUmo() {
		return umo;
	}

	public void setUmo(String umo) {
		this.umo = umo;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public String getQuantity() {
		return quantity;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	

}
