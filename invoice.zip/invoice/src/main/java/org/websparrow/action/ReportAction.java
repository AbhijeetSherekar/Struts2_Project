package org.websparrow.action;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.websparrow.bean.InvoiceBean;
import org.websparrow.dao.Admin;

import com.opensymphony.xwork2.ActionSupport;

public class ReportAction extends ActionSupport {

	private static final long serialVersionUID = 6329394260276112660L;
	ResultSet rs = null;
	InvoiceBean bean = null;
	List<InvoiceBean> beanList = null;
	Admin admin = new Admin();
	private boolean noData = false;

	@Override
	public String execute() throws Exception {
		try {
			beanList = new ArrayList<InvoiceBean>();
			rs = admin.report();
			int i = 0;
			if (rs != null) {
				while (rs.next()) {
					i++;
					bean = new InvoiceBean();
					bean.setSrNo(i);
					bean.setInvoiceId(rs.getInt("invoiceId"));
					bean.setCustomerName(rs.getString("customerName"));
					bean.setInvoiceDate(rs.getString("invoiceDate"));
                    bean.setTotal_invoice_amount(rs.getString("total_invoice_amount"));
					beanList.add(bean);
				} 
			}
			if (i == 0) {
				noData = false;
			} else {
				noData = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "REPORT";
	}

	
	public boolean isNoData() {
		return noData;
	}

	public void setNoData(boolean noData) {
		this.noData = noData;
	}

	public List<InvoiceBean> getBeanList() {
		return beanList;
	}

	public void setBeanList(List<InvoiceBean> beanList) {
		this.beanList = beanList;
	}

}
