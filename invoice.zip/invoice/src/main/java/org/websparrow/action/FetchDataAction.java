package org.websparrow.action;

import java.sql.ResultSet;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;
import org.apache.struts2.action.ServletResponseAware;
import org.websparrow.dao.Admin;
import com.opensymphony.xwork2.ActionSupport;

public class FetchDataAction extends ActionSupport implements ServletResponseAware {
	private static final long serialVersionUID = -1905974197186620917L;
	String itemname ="",price="",Pric="";
	private String msg = "";
	ResultSet rs = null;
	Admin dao = new Admin();
	String submitType;
	HttpServletRequest req;
	HttpServletResponse response = null;
	
	@Override
	public String execute() throws Exception {
		HttpServletResponse response = ServletActionContext.getResponse();
		try {
			
			
			
			    rs = dao.fetchUserDetail(itemname);
				if(itemname=="SELECT")
				{ 
					
					itemname=null;
					price=null;
					
				}else if (rs != null) {
					while (rs.next()) {
						price = rs.getString("price");
					}
				}
				
				response.setContentType("text/html");
				response.getWriter().write(price);
				
			

		}
		catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println(price);
		
		return null;
		
	
	}

	public String getItemname() {
		return itemname;
	}



	public void setItemname(String itemname) {
		this.itemname = itemname;
	}



	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public String getSubmitType() {
		return submitType;
	}

	public void setSubmitType(String submitType) {
		this.submitType = submitType;
	}

	@Override
	public void withServletResponse(HttpServletResponse arg0) {
		// TODO Auto-generated method stub
		
	}
	
	

	
	

}
