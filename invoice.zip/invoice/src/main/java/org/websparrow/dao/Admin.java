package org.websparrow.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import org.websparrow.bean.InvoiceBean;

public class Admin {

	// method for create connection
	public static Connection getConnection() throws Exception {
		try {

			Class.forName("org.postgresql.Driver");
			return DriverManager.getConnection("jdbc:postgresql://localhost:5432/postgres", "postgres", "postgres");

		} catch (SQLException e) {
			throw new RuntimeException("Cannot connect to database", e);
		}
	}

	// method for save user data in database
	public int registerUser(int invoiceId, String invoiceDate, String customerName, String item, String item1,
			String item2, String item3, String item4, String item5, String item6, String item7, String item8,
			String item9, String price, String price1, String price2, String price3, String price4, String price5,
			String price6, String price7, String price8, String price9, String quantity, String quantity1,
			String quantity2, String quantity3, String quantity4, String quantity5, String quantity6, String quantity7,
			String quantity8, String quantity9, String totalPrice, String totalPrice1, String totalPrice2,
			String totalPrice3, String totalPrice4, String totalPrice5, String totalPrice6, String totalPrice7,
			String totalPrice8, String totalPrice9, String total_invoice_amount) throws Exception {
		int i = 0;

		try {

			if (item != null) {
				PreparedStatement s = getConnection().prepareStatement("SELECT MAX(invoiceId)+1  FROM invoices");
				ResultSet rs = s.executeQuery();
				invoiceId = rs.next() ? rs.getInt(1) : 1;
				if(invoiceId==0) {
					invoiceId=invoiceId+1;
				}

				String sql = "INSERT INTO invoices(invoiceId,invoiceDate, customerName, item,price, quantity, totalPrice, total_invoice_amount) VALUES(?,?,?,?,?,?,?,?)";
				PreparedStatement ps = getConnection().prepareStatement(sql);
				ps.setInt(1, invoiceId);
				ps.setString(2, invoiceDate);
				ps.setString(3, customerName);
				ps.setString(4, item);
				ps.setString(5, price);
				ps.setString(6, quantity);
				ps.setString(7, totalPrice);
				ps.setString(8, total_invoice_amount);
				i = ps.executeUpdate();

			} else {
				InvoiceBean invoice = new InvoiceBean();
				invoice.setPrice(null);
				invoice.setQuantity(null);
				invoice.setQuantity(null);
			}

			if (item1 != null && item1 != "") {

				String sql = "INSERT INTO invoices(invoiceId,invoiceDate, customerName, item,price, quantity, totalPrice, total_invoice_amount) VALUES(?,?,?,?,?,?,?,?)";
				PreparedStatement ps = getConnection().prepareStatement(sql);
				ps.setInt(1, invoiceId);
				ps.setString(2, invoiceDate);
				ps.setString(3, customerName);
				ps.setString(4, item1);
				ps.setString(5, price1);
				ps.setString(6, quantity1);
				ps.setString(7, totalPrice1);
				ps.setString(8, total_invoice_amount);
				i = ps.executeUpdate();
			} else {
				InvoiceBean invoice = new InvoiceBean();
				invoice.setPrice(null);
				invoice.setQuantity(null);
				invoice.setQuantity(null);
			}

			if (item2 != null && item2 != "") {

				String sql = "INSERT INTO invoices(invoiceId,invoiceDate, customerName, item,price, quantity, totalPrice, total_invoice_amount) VALUES(?,?,?,?,?,?,?,?)";
				PreparedStatement ps = getConnection().prepareStatement(sql);
				ps.setInt(1, invoiceId);
				ps.setString(2, invoiceDate);
				ps.setString(3, customerName);
				ps.setString(4, item2);
				ps.setString(5, price2);
				ps.setString(6, quantity2);
				ps.setString(7, totalPrice2);
				ps.setString(8, total_invoice_amount);
				i = ps.executeUpdate();
			} else {
				InvoiceBean invoice = new InvoiceBean();
				invoice.setPrice(null);
				invoice.setQuantity(null);
				invoice.setQuantity(null);
			}

			if (item3 != null && item3 != "") {

				String sql = "INSERT INTO invoices(invoiceId,invoiceDate, customerName, item,price, quantity, totalPrice, total_invoice_amount) VALUES(?,?,?,?,?,?,?,?)";
				PreparedStatement ps = getConnection().prepareStatement(sql);
				ps.setInt(1, invoiceId);
				ps.setString(2, invoiceDate);
				ps.setString(3, customerName);
				ps.setString(4, item3);
				ps.setString(5, price3);
				ps.setString(6, quantity3);
				ps.setString(7, totalPrice3);
				ps.setString(8, total_invoice_amount);
				i = ps.executeUpdate();
			} else {
				InvoiceBean invoice = new InvoiceBean();
				invoice.setPrice(null);
				invoice.setQuantity(null);
				invoice.setQuantity(null);
			}

			if (item4 != null && item4 != "") {

				String sql = "INSERT INTO invoices(invoiceId,invoiceDate, customerName, item,price, quantity, totalPrice, total_invoice_amount) VALUES(?,?,?,?,?,?,?,?)";
				PreparedStatement ps = getConnection().prepareStatement(sql);
				ps.setInt(1, invoiceId);
				ps.setString(2, invoiceDate);
				ps.setString(3, customerName);
				ps.setString(4, item4);
				ps.setString(5, price4);
				ps.setString(6, quantity4);
				ps.setString(7, totalPrice4);
				ps.setString(8, total_invoice_amount);
				i = ps.executeUpdate();
			} else {
				InvoiceBean invoice = new InvoiceBean();
				invoice.setPrice(null);
				invoice.setQuantity(null);
				invoice.setQuantity(null);
			}

			if (item5 != null && item5 != "") {

				String sql = "INSERT INTO invoices(invoiceId,invoiceDate, customerName, item,price, quantity, totalPrice, total_invoice_amount) VALUES(?,?,?,?,?,?,?,?)";
				PreparedStatement ps = getConnection().prepareStatement(sql);
				ps.setInt(1, invoiceId);
				ps.setString(2, invoiceDate);
				ps.setString(3, customerName);
				ps.setString(4, item5);
				ps.setString(5, price5);
				ps.setString(6, quantity5);
				ps.setString(7, totalPrice5);
				ps.setString(8, total_invoice_amount);
				i = ps.executeUpdate();
			} else {
				InvoiceBean invoice = new InvoiceBean();
				invoice.setPrice(null);
				invoice.setQuantity(null);
				invoice.setQuantity(null);
			}

			if (item6 != null && item6 != "") {

				String sql = "INSERT INTO invoices(invoiceId,invoiceDate, customerName, item,price, quantity, totalPrice, total_invoice_amount) VALUES(?,?,?,?,?,?,?,?)";
				PreparedStatement ps = getConnection().prepareStatement(sql);
				ps.setInt(1, invoiceId);
				ps.setString(2, invoiceDate);
				ps.setString(3, customerName);
				ps.setString(4, item6);
				ps.setString(5, price6);
				ps.setString(6, quantity6);
				ps.setString(7, totalPrice6);
				ps.setString(8, total_invoice_amount);
				i = ps.executeUpdate();
			} else {
				InvoiceBean invoice = new InvoiceBean();
				invoice.setPrice(null);
				invoice.setQuantity(null);
				invoice.setQuantity(null);
			}

			if (item7 != null && item7 != "") {

				String sql = "INSERT INTO invoices(invoiceId,invoiceDate, customerName, item,price, quantity, totalPrice, total_invoice_amount) VALUES(?,?,?,?,?,?,?,?)";
				PreparedStatement ps = getConnection().prepareStatement(sql);
				ps.setInt(1, invoiceId);
				ps.setString(2, invoiceDate);
				ps.setString(3, customerName);
				ps.setString(4, item7);
				ps.setString(5, price7);
				ps.setString(6, quantity7);
				ps.setString(7, totalPrice7);
				ps.setString(8, total_invoice_amount);
				i = ps.executeUpdate();
			} else {
				InvoiceBean invoice = new InvoiceBean();
				invoice.setPrice(null);
				invoice.setQuantity(null);
				invoice.setQuantity(null);
			}

			if (item8 != null && item8 != "") {

				String sql = "INSERT INTO invoices(invoiceId,invoiceDate, customerName, item,price, quantity, totalPrice, total_invoice_amount) VALUES(?,?,?,?,?,?,?,?)";
				PreparedStatement ps = getConnection().prepareStatement(sql);
				ps.setInt(1, invoiceId);
				ps.setString(2, invoiceDate);
				ps.setString(3, customerName);
				ps.setString(4, item8);
				ps.setString(5, price8);
				ps.setString(6, quantity8);
				ps.setString(7, totalPrice8);
				ps.setString(8, total_invoice_amount);
				i = ps.executeUpdate();
			} else {
				InvoiceBean invoice = new InvoiceBean();
				invoice.setPrice(null);
				invoice.setQuantity(null);
				invoice.setQuantity(null);
			}

			if (item9 != null && item9 != "") {

				String sql = "INSERT INTO invoices(invoiceId,invoiceDate, customerName, item,price, quantity, totalPrice, total_invoice_amount) VALUES(?,?,?,?,?,?,?,?)";
				PreparedStatement ps = getConnection().prepareStatement(sql);
				ps.setInt(1, invoiceId);
				ps.setString(2, invoiceDate);
				ps.setString(3, customerName);
				ps.setString(4, item9);
				ps.setString(5, price9);
				ps.setString(6, quantity9);
				ps.setString(7, totalPrice9);
				ps.setString(8, total_invoice_amount);
				i = ps.executeUpdate();
			} else {
				InvoiceBean invoice = new InvoiceBean();
				invoice.setPrice(null);
				invoice.setQuantity(null);
				invoice.setQuantity(null);
			}

			return invoiceId;
		} catch (Exception e) {
			e.printStackTrace();
			return i;
		} finally {
			if (getConnection() != null) {
				getConnection().close();
			}
		}
	}

	// method for fetch saved user data
	public ResultSet report() throws SQLException, Exception {
		ResultSet rs = null;
		try {
			String sql = "SELECT distinct(invoiceid),invoiceDate, customerName,   total_invoice_amount  FROM invoices ORDER BY invoiceid ;";
			PreparedStatement ps = getConnection().prepareStatement(sql);
			rs = ps.executeQuery();
			return rs;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			if (getConnection() != null) {
				getConnection().close();
			}
		}
	}

	public ResultSet fetchUserDetail(String itemName) throws SQLException, Exception {
		ResultSet rs = null;
		try {
			String sql = "SELECT price FROM item_details WHERE itemName=?";
			PreparedStatement ps = getConnection().prepareStatement(sql);
			ps.setString(1, itemName);
			rs = ps.executeQuery();
			return rs;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			if (getConnection() != null) {
				getConnection().close();
			}
		}
	}

	public int getMaxInvoiceId() throws Exception {
		int maxInvoiceId = 0;
		String sql = "SELECT MAX(invoiceId) as maxInvoiceId FROM invoices";
		try (PreparedStatement stmt = getConnection().prepareStatement(sql); ResultSet rs = stmt.executeQuery()) {
			if (rs.next()) {
				maxInvoiceId = rs.getInt("maxInvoiceId");
			}
		} catch (SQLException e) {
			throw new SQLException("Error getting max invoiceId: " + e.getMessage());
		}
		return maxInvoiceId;
	}

	public int getMaxInvoiceId1() throws Exception {
		int maxInvoiceId = 0;
		String sql = "SELECT MAX(invoiceId)+1  FROM invoices";
		try (PreparedStatement stmt = getConnection().prepareStatement(sql); ResultSet rs = stmt.executeQuery()) {
			if (rs.next()) {
				maxInvoiceId = rs.getInt("maxInvoiceId");
			}
		} catch (SQLException e) {
			throw new SQLException("Error getting max invoiceId: " + e.getMessage());
		}
		return maxInvoiceId;
	}

	public ResultSet fetchUserDetails(int invoiceId) throws SQLException, Exception {
		ResultSet rs = null;
		try {
			String sql = "SELECT invoiceDate, item,customerName, price, quantity, totalPrice, total_invoice_amount  FROM invoices WHERE invoiceId=?";
			PreparedStatement ps = getConnection().prepareStatement(sql);
			ps.setInt(1, invoiceId);

			rs = ps.executeQuery();
			return rs;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			if (getConnection() != null) {
				getConnection().close();
			}
		}
	}

	

	// FETCH USER DETAILS
	public ResultSet fetchUserDetails1(int invoiceId) throws SQLException, Exception {
		ResultSet rs = null;
		try {
			String sql = "SELECT  invoiceId,invoiceDate, item,customerName, price, quantity, totalPrice, total_invoice_amount  FROM invoices WHERE  invoiceId=?";
			PreparedStatement ps = getConnection().prepareStatement(sql);
			ps.setInt(1, invoiceId);
			rs = ps.executeQuery();
			return rs;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			if (getConnection() != null) {
				getConnection().close();
			}
		}
	}

	// method for update new data in database
	public int updateUserDetails(int invoiceId, String invoiceDate, String customerName, String item, String item1,
			String item2, String item3, String item4, String item5, String item6, String item7, String item8,
			String item9, String price, String price1, String price2, String price3, String price4, String price5,
			String price6, String price7, String price8, String price9, String quantity, String quantity1,
			String quantity2, String quantity3, String quantity4, String quantity5, String quantity6, String quantity7,
			String quantity8, String quantity9, String totalPrice, String totalPrice1, String totalPrice2,
			String totalPrice3, String totalPrice4, String totalPrice5, String totalPrice6, String totalPrice7,
			String totalPrice8, String totalPrice9, String total_invoice_amount) throws SQLException, Exception {
		getConnection().setAutoCommit(false);
		int i = 0;
		try {
			if (item != null) {
				

				String sql = "INSERT INTO invoices(invoiceId,invoiceDate, customerName, item,price, quantity, totalPrice, total_invoice_amount) VALUES(?,?,?,?,?,?,?,?)";
				PreparedStatement ps = getConnection().prepareStatement(sql);
				ps.setInt(1, invoiceId);
				ps.setString(2, invoiceDate);
				ps.setString(3, customerName);
				ps.setString(4, item);
				ps.setString(5, price);
				ps.setString(6, quantity);
				ps.setString(7, totalPrice);
				ps.setString(8, total_invoice_amount);
				i = ps.executeUpdate();

			} else {
				InvoiceBean invoice = new InvoiceBean();
				invoice.setPrice(null);
				invoice.setQuantity(null);
				invoice.setQuantity(null);
			}

			if (item1 != null && item1 != "") {

				String sql = "INSERT INTO invoices(invoiceId,invoiceDate, customerName, item,price, quantity, totalPrice, total_invoice_amount) VALUES(?,?,?,?,?,?,?,?)";
				PreparedStatement ps = getConnection().prepareStatement(sql);
				ps.setInt(1, invoiceId);
				ps.setString(2, invoiceDate);
				ps.setString(3, customerName);
				ps.setString(4, item1);
				ps.setString(5, price1);
				ps.setString(6, quantity1);
				ps.setString(7, totalPrice1);
				ps.setString(8, total_invoice_amount);
				i = ps.executeUpdate();
			} else {
				InvoiceBean invoice = new InvoiceBean();
				invoice.setPrice(null);
				invoice.setQuantity(null);
				invoice.setQuantity(null);
			}

			if (item2 != null && item2 != "") {

				String sql = "INSERT INTO invoices(invoiceId,invoiceDate, customerName, item,price, quantity, totalPrice, total_invoice_amount) VALUES(?,?,?,?,?,?,?,?)";
				PreparedStatement ps = getConnection().prepareStatement(sql);
				ps.setInt(1, invoiceId);
				ps.setString(2, invoiceDate);
				ps.setString(3, customerName);
				ps.setString(4, item2);
				ps.setString(5, price2);
				ps.setString(6, quantity2);
				ps.setString(7, totalPrice2);
				ps.setString(8, total_invoice_amount);
				i = ps.executeUpdate();
			} else {
				InvoiceBean invoice = new InvoiceBean();
				invoice.setPrice(null);
				invoice.setQuantity(null);
				invoice.setQuantity(null);
			}

			if (item3 != null && item3 != "") {

				String sql = "INSERT INTO invoices(invoiceId,invoiceDate, customerName, item,price, quantity, totalPrice, total_invoice_amount) VALUES(?,?,?,?,?,?,?,?)";
				PreparedStatement ps = getConnection().prepareStatement(sql);
				ps.setInt(1, invoiceId);
				ps.setString(2, invoiceDate);
				ps.setString(3, customerName);
				ps.setString(4, item3);
				ps.setString(5, price3);
				ps.setString(6, quantity3);
				ps.setString(7, totalPrice3);
				ps.setString(8, total_invoice_amount);
				i = ps.executeUpdate();
			} else {
				InvoiceBean invoice = new InvoiceBean();
				invoice.setPrice(null);
				invoice.setQuantity(null);
				invoice.setQuantity(null);
			}

			if (item4 != null && item4 != "") {

				String sql = "INSERT INTO invoices(invoiceId,invoiceDate, customerName, item,price, quantity, totalPrice, total_invoice_amount) VALUES(?,?,?,?,?,?,?,?)";
				PreparedStatement ps = getConnection().prepareStatement(sql);
				ps.setInt(1, invoiceId);
				ps.setString(2, invoiceDate);
				ps.setString(3, customerName);
				ps.setString(4, item4);
				ps.setString(5, price4);
				ps.setString(6, quantity4);
				ps.setString(7, totalPrice4);
				ps.setString(8, total_invoice_amount);
				i = ps.executeUpdate();
			} else {
				InvoiceBean invoice = new InvoiceBean();
				invoice.setPrice(null);
				invoice.setQuantity(null);
				invoice.setQuantity(null);
			}

			if (item5 != null && item5 != "") {

				String sql = "INSERT INTO invoices(invoiceId,invoiceDate, customerName, item,price, quantity, totalPrice, total_invoice_amount) VALUES(?,?,?,?,?,?,?,?)";
				PreparedStatement ps = getConnection().prepareStatement(sql);
				ps.setInt(1, invoiceId);
				ps.setString(2, invoiceDate);
				ps.setString(3, customerName);
				ps.setString(4, item5);
				ps.setString(5, price5);
				ps.setString(6, quantity5);
				ps.setString(7, totalPrice5);
				ps.setString(8, total_invoice_amount);
				i = ps.executeUpdate();
			} else {
				InvoiceBean invoice = new InvoiceBean();
				invoice.setPrice(null);
				invoice.setQuantity(null);
				invoice.setQuantity(null);
			}

			if (item6 != null && item6 != "") {

				String sql = "INSERT INTO invoices(invoiceId,invoiceDate, customerName, item,price, quantity, totalPrice, total_invoice_amount) VALUES(?,?,?,?,?,?,?,?)";
				PreparedStatement ps = getConnection().prepareStatement(sql);
				ps.setInt(1, invoiceId);
				ps.setString(2, invoiceDate);
				ps.setString(3, customerName);
				ps.setString(4, item6);
				ps.setString(5, price6);
				ps.setString(6, quantity6);
				ps.setString(7, totalPrice6);
				ps.setString(8, total_invoice_amount);
				i = ps.executeUpdate();
			} else {
				InvoiceBean invoice = new InvoiceBean();
				invoice.setPrice(null);
				invoice.setQuantity(null);
				invoice.setQuantity(null);
			}

			if (item7 != null && item7 != "") {

				String sql = "INSERT INTO invoices(invoiceId,invoiceDate, customerName, item,price, quantity, totalPrice, total_invoice_amount) VALUES(?,?,?,?,?,?,?,?)";
				PreparedStatement ps = getConnection().prepareStatement(sql);
				ps.setInt(1, invoiceId);
				ps.setString(2, invoiceDate);
				ps.setString(3, customerName);
				ps.setString(4, item7);
				ps.setString(5, price7);
				ps.setString(6, quantity7);
				ps.setString(7, totalPrice7);
				ps.setString(8, total_invoice_amount);
				i = ps.executeUpdate();
			} else {
				InvoiceBean invoice = new InvoiceBean();
				invoice.setPrice(null);
				invoice.setQuantity(null);
				invoice.setQuantity(null);
			}

			if (item8 != null && item8 != "") {

				String sql = "INSERT INTO invoices(invoiceId,invoiceDate, customerName, item,price, quantity, totalPrice, total_invoice_amount) VALUES(?,?,?,?,?,?,?,?)";
				PreparedStatement ps = getConnection().prepareStatement(sql);
				ps.setInt(1, invoiceId);
				ps.setString(2, invoiceDate);
				ps.setString(3, customerName);
				ps.setString(4, item8);
				ps.setString(5, price8);
				ps.setString(6, quantity8);
				ps.setString(7, totalPrice8);
				ps.setString(8, total_invoice_amount);
				i = ps.executeUpdate();
			} else {
				InvoiceBean invoice = new InvoiceBean();
				invoice.setPrice(null);
				invoice.setQuantity(null);
				invoice.setQuantity(null);
			}

			if (item9 != null && item9 != "") {

				String sql = "INSERT INTO invoices(invoiceId,invoiceDate, customerName, item,price, quantity, totalPrice, total_invoice_amount) VALUES(?,?,?,?,?,?,?,?)";
				PreparedStatement ps = getConnection().prepareStatement(sql);
				ps.setInt(1, invoiceId);
				ps.setString(2, invoiceDate);
				ps.setString(3, customerName);
				ps.setString(4, item9);
				ps.setString(5, price9);
				ps.setString(6, quantity9);
				ps.setString(7, totalPrice9);
				ps.setString(8, total_invoice_amount);
				i = ps.executeUpdate();
			} else {
				InvoiceBean invoice = new InvoiceBean();
				invoice.setPrice(null);
				invoice.setQuantity(null);
				invoice.setQuantity(null);
			}
			return i;
		} catch (Exception e) {
			e.printStackTrace();
			getConnection().rollback();
			return 0;
		} finally {
			if (getConnection() != null) {
				getConnection().close();
			}
		}
	}

	// method for delete the record
	public int deleteUserDetails(int invoiceId) throws SQLException, Exception {
		getConnection().setAutoCommit(false);
		int i = 0;
		try {
			String sql = "DELETE FROM invoices WHERE invoiceId=?";
			PreparedStatement ps = getConnection().prepareStatement(sql);
			ps.setInt(1, invoiceId);
			i = ps.executeUpdate();
			return i;
		} catch (Exception e) {
			e.printStackTrace();
			getConnection().rollback();
			return 0;
		} finally {
			if (getConnection() != null) {
				getConnection().close();
			}
		}
	}

	public List<String> getItemNames() throws SQLException, Exception {
		List<String> itemNames = new ArrayList<>();
		try {

			String sql = "select itemName from item_details";
			PreparedStatement stmt = getConnection().prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				itemNames.add(rs.getString("itemName"));
			}
		} catch (SQLException e) {
			// handle the exception
		}

		return itemNames;
	}

	public List<String> getcustomerNames() throws SQLException, Exception {
		List<String> customerName = new ArrayList<>();
		try {

			String sql = "select customerName from customer_details order by  customerName ASC";
			PreparedStatement stmt = getConnection().prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				customerName.add(rs.getString("customerName"));
			}
		} catch (SQLException e) {
			// handle the exception
		}

		return customerName;
	}

}
